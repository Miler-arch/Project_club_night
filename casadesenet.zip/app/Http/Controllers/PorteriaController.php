<?php

namespace App\Http\Controllers;

use App\Models\Chica;
use App\Models\Client;
use App\Models\Porteria;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PorteriaController extends Controller
{
    public function index()
    {
        $clients = Client::all();
        $chicas = Chica::all();
        $users = User::all();
        return view('porterias.index', compact('users', 'chicas', 'clients'));
    }

    public function create()
    {
        $clients = Client::all();
        $chicas = Chica::all();
        $users = User::all();
        return view('porterias.create', compact('clients', 'chicas', 'users'));
    }

    public function store(Request $request)
    {
        $porterias = Porteria::create($request->all());
        return redirect()->route('porterias.registros', $porterias);
    }

    public function verRegistros()
    {
        $porterias = Porteria::all();
        $porterias = Porteria::paginate(50);
        $clients = Client::all();
        $chicas = Chica::all();
        $users = User::all();
        return view('porterias.registros', compact('porterias', 'clients', 'chicas', 'users'));
    }

    // public function show()
    // {
    //     $porterias = Porteria::all();
    //     $porterias = Porteria::paginate(50);
    //             $clients = Client::all();
    //     $chicas = Chica::all();
    //     $users = User::all();
    //     return view('porterias.registros', compact('porterias', 'clients', 'chicas', 'users'));
    // }

    public function edit($id)
    {
        $porterias = Porteria::find($id);
        return view('porterias.edit', compact('porterias'));
    }

    public function update(Request $request, $id)
    {
        $porterias = Porteria::find($id)->update($request->all());
        return redirect()->route('porterias.index', $porterias);
    }

    public function destroy($id)
    {
        $porterias = Porteria::find($id)->delete();
        return redirect()->route('porterias.index', $porterias);
    }
}
