<?php $__env->startSection('content'); ?>
    <div class="content">
      <div class="content-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-header card-header-primary">
                    <h4 class="card-title">Manillas</h4>
                    <p class="card-category">Manillas registrados</p>
                  </div>
                  <div class="card-body">
                    <?php if(session('success')): ?>
                      <div class="alert alert-success" role="success">
                        <?php echo e(session('success')); ?>

                      </div>
                    <?php endif; ?>
                    <div class="row">
                      <div class="col-12 text-right">
                        
                        <a href="<?php echo e(route('manillas.create')); ?>" class="btn btn-sm btn-facebook">Registrar Manilla</a>
                        
                      </div>
                    </div>
                    <div class="table-responsive">
                      <table class="table">
                        <thead class="text-primary">
                          <th>ID</th>
                          <th>Color</th>
                          <th>Precio</th>
                          <th>Fecha/Hora</th>
                          <th class="text-right">Acciones</th>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $manillas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manilla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($manilla->id); ?></td>
                            <td><?php echo e($manilla->color); ?></td>
                            <td><?php echo e($manilla->precio); ?> Bs.</td>
                            <td><?php echo e($manilla->created_at); ?></td>

                            <td class="td-actions text-right">
                              
                              <a href="<?php echo e(route('manillas.show', $manilla->id)); ?>" class="btn btn-info"><i class="material-icons">person</i></a>
                              
                              
                              <a href="<?php echo e(route('manillas.edit', $manilla->id)); ?>" class="btn btn-warning"><i class="material-icons">edit</i></a>
                              
                              
                              <form action="<?php echo e(route('manillas.destroy', $manilla->id)); ?>" method="post" style="display: inline-block;" class="form-eliminar"> 
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger" type="submit">
                                  <i class="material-icons">close</i>
                                </button>
                              </form> 
                              
                            </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                    <div class="card-footer justify-content-center">
                      <?php echo e($manillas->links()); ?>

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php if(session('eliminar') == 'ok'): ?>
      <script>
        Swal.fire(
      'Eliminado',
      'La manilla ha sido eliminada.',
      'success'
        )
      </script>
    <?php endif; ?>
<script type="text/javascript">
  $('.form-eliminar').submit(function(e){

  e.preventDefault();
  
  Swal.fire({
  title: '¿Esta seguro?',
  text: "La manilla se eliminara definitivamente.",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Si, eliminar',
  cancelButtonText: 'Cancelar'
  }).then((result) => {
    if (result.value) {
    //   Swal.fire(
    //     'Deleted!',
    //     'Your file has been deleted.',
    //     'success'
    // )
    this.submit();
  }
})
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['activePage' => 'manillas', 'titlePage' => 'Manillas'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\casadesenet\resources\views/manillas/index.blade.php ENDPATH**/ ?>