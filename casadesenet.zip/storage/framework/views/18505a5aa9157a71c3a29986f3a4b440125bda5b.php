
    
    <?php /**PATH C:\laragon\www\casadesenet\resources\views/layouts/footers/auth.blade.php ENDPATH**/ ?>