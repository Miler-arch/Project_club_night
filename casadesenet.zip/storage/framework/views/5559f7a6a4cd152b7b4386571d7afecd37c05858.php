<?php $__env->startSection('content'); ?>
    <div class="content">
      <div class="content-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-header card-header-primary">
                    <h4 class="card-title">Porteria</h4>
                    <p class="card-category">Registros de porteria</p>
                    <a href="<?php echo e(route('porterias.index')); ?>" class="btn bg-dark float-right">Atras</a>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-shopping">
                        <thead class="text-primary">
                            <th class="font-weight-bold">ID</th>
                            <th class="font-weight-bold">Nombre</th>
                            <th class="font-weight-bold">Estado</th>
                            <th class="font-weight-bold">Motivo</th>
                            <th class="font-weight-bold">Fecha / Hora</th>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $porterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $porteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($porteria->id); ?></td>
                            <td>
                                <?php if($porteria->user != null): ?>
                                    <?php echo e($porteria->user->name); ?>

                                <?php elseif($porteria->chica != null): ?>
                                    <?php echo e($porteria->chica->name); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <a class="btn btn-success" href="<?php echo e(route('porterias.show', $porteria)); ?>"><?php echo e($porteria->type_entry); ?></a>
                            </td>
                            <td>
                              <?php if($porteria->reason): ?>
                                  <?php echo e($porteria->reason); ?>

                              <?php else: ?>
                                <span class="text-danger">No tiene motivo</span>
                              <?php endif; ?>

                            </td>
                            <td><?php echo e($porteria->created_at); ?></td>

                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                    <div class="card-footer justify-content-center">
                      <?php echo e($porterias->links()); ?>

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php if(session('eliminar') == 'ok'): ?>
      <script>
        Swal.fire(
      'Eliminado',
      'La pieza ha sido eliminada.',
      'success'
        )
      </script>
    <?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script type="text/javascript">
    $('.form-eliminar').submit(function(e){

    e.preventDefault();

    Swal.fire({
    title: '¿Esta seguro?',
    text: "La porteria se eliminara definitivamente.",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Si, eliminar',
    cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.value) {
        //   Swal.fire(
        //     'Deleted!',
        //     'Your file has been deleted.',
        //     'success'
        // )
        this.submit();
    }
    })
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', ['activePage' => 'porterias', 'titlePage' => 'Porteria'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\casadesenet\resources\views/porterias/registros.blade.php ENDPATH**/ ?>