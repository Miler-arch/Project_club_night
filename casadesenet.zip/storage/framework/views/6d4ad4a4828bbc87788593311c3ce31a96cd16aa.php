<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">  
        <link rel="stylesheet" href="<?php echo e(asset('css/principal.css')); ?>">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Dancing+Script&display=swap" rel="stylesheet">
    </head>
    <body>
        <div class="container">
            <span style="--l: 'B'; margin-left:-25px">B</span>
            <span style="--l: 'i';">i</span>
            <span style="--l: 'e';">e</span>
            <span style="--l: 'n';">n</span>
            <span style="--l: 'v';">v</span>
            <span style="--l: 'e';">e</span>
            <span style="--l: 'n';">n</span>
            <span style="--l: 'i';">i</span>
            <span style="--l: 'd';">d</span>
            <span style="--l: 'o';">o</span>

            <span style="--l: 'a'; margin-left:20px">a</span>

            <span style="--l: 'l'; margin-left:20px">l</span>
            <span style="--l: 'a';">a</span><br>
            <span style="--l: 'C'; margin-left:20px">C</span>
            <span style="--l: 'a';">a</span>
            <span style="--l: 's';">s</span>
            <span style="--l: 'a';">a</span>
            <span style="--l: 'd'; margin-left:20px">d</span>
            <span style="--l: 'e';">e</span>
            <span style="--l: 's'; margin-left:20px">s</span>
            <span style="--l: 'e';">e</span>
            <span style="--l: 'n';">n</span>
            <span style="--l: 'e';">e</span>
            <span style="--l: 't';">t</span>
       
        <div>
            <?php if(Route::has('login')): ?>
                <div class="text1">
                    <?php if(auth()->guard()->check()): ?>
                        <div class="btn"><a href="<?php echo e(url('/home')); ?>">Volver al Inicio</a></div>
                    <?php else: ?>
                        <div class="btn"><a href="<?php echo e(route('login')); ?>">Iniciar Sesión</a></div>

                        <?php if(Route::has('register')): ?>
                        <div class="btn"><a href="<?php echo e(route('register')); ?>">Registrarse</a></div>
                        <?php endif; ?>
                    <?php endif; ?>
                    
                </div>
            <?php endif; ?>
          
       
        </div>
    </div> 
    </body>
</html>
<?php /**PATH C:\Users\Arnez\Desktop\casadesenet-main\resources\views/welcome.blade.php ENDPATH**/ ?>