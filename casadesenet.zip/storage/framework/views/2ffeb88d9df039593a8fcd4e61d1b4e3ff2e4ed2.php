<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form action="<?php echo e(route('porterias.store')); ?>" method="post" class="form-horizontal">
                <?php echo csrf_field(); ?>
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Porteria</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="font-form d-flex align-items-center">
                                        <i class='bx bxs-id-card' style='color:#18abd4; font-size:25px;'></i>
                                        <span>Nombre:</span>
                                    </label>
                                    <select class="js-example-basic-single w-100" id="user_select" name="user_id" placeholder="Select a person...">
                                        <option value="">Seleccione un usuario...</option>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="font-form">
                                        Estado :
                                    </label>
                                    <div>
                                        <?php if(isset($user) && $user->hasRole('chica')): ?>
                                            <input type="text" value="<?php echo e($user->phone); ?>" readonly>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div >
                                    <label class="font-form d-flex align-items-center">
                                        <i class='bx bxs-id-card' style='color:#f70202; font-size:25px;'></i>
                                        Bloquear :
                                    </label>
                                    <textarea placeholder="Ingrese el motivo" name="reason" id="" class="form-control" cols="30" rows="10"></textarea>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="font-form d-flex align-items-center">
                                        <i class='bx bxs-id-card' style='color:#0b69e4; font-size:25px;'></i>
                                        Autorizado por :
                                    </label>
                                    <select name="user_id" id="" class="form-control">
                                        <option value="">Selecciones un usuario...</option>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="font-form">
                                        <i class='bx bxs-id-card' style='color:#d10f0f; font-size:25px;'></i>
                                        <span>Foto :</span>
                                    </label>
                                    <img id="photo_user"  width="300" height="300">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="font-form d-flex align-items-center">
                                        <i class='bx bxs-id-card' style='color:#115dd7; font-size:25px;'></i>
                                        Tipo de personal :
                                    </label>
                                    <select name="type_user" id="" class="form-control">
                                        <option value="" >Seleccione una opción :</option>
                                        <option value="1">Chica</option>
                                        <option value="2">Cajero</option>
                                        <option value="3">Garzon</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="font-form d-flex align-items-center">
                                        <i class='bx bxs-id-card' style='color:#0677e0; font-size:25px;'></i>
                                        Sanidad :
                                    </label>
                                    <?php if(isset($chicas)): ?>
                                        <?php $__currentLoopData = $chicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($chica->health_card_expiry_date): ?>
                                                <span class="btn btn-success">Activo</span>
                                            <?php else: ?>
                                                <span class="btn btn-danger">Inactivo</span>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="font-form d-flex align-items-center">
                                        <i class='bx bxs-id-card' style='color:#ee0d0d; font-size:25px;'></i>
                                        Vencimiento Sanidad :
                                    </label>
                                    <?php if(isset($chicas)): ?>
                                        <?php $__currentLoopData = $chicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($chica->health_card_expiry_date): ?>
                                                <span class="btn btn-success">Activo</span>
                                            <?php else: ?>
                                                <span class="btn btn-danger">Inactivo</span>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div>
                                    <label class="font-form d-flex align-items-center">
                                        <i class='bx bxs-id-card' style='color:#c61111; font-size:25px;'></i>
                                        Código de Sanidad :
                                    </label>
                                    <?php if(isset($chicas)): ?>
                                        <input type="text" name="code_card" readonly class="form-control">
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div>
                                    <label class="font-form d-flex align-items-center">
                                        <i class='bx bxs-id-card' style='color:#dc0606; font-size:25px;'></i>
                                        Número de Celular :
                                    </label>
                                    <input type="text" id="phone_user" readonly class="form-control">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div>
                                    <label class="font-form d-flex align-items-center">
                                        <i class='bx bxs-id-card' style='color:#dc0606; font-size:25px;'></i>
                                        Número de Carnet :
                                    </label>
                                    <input type="text" id="ci_user" readonly class="form-control">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer ml-auto mr-auto">
                        <a href="<?php echo e(route('porterias.index')); ?>" class="btn btn-success mr-3">Cancelar</a>
                        <button type="submit" class="btn btn-primary">Guardar</button>
                    </div>
                </div>
                </form>
    
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function() {
        $('.js-example-basic-single').select2();
    });
</script>

<script>
    $(document).ready(function () {
        $('#user_select').change(function () {
            var userId = $(this).val();

            // Realiza una solicitud AJAX para obtener el número de teléfono del usuario seleccionado
            $.ajax({
                url: '/get-user-phone', // Debes definir esta ruta en tu archivo de rutas
                method: 'POST',
                data: { user_id: userId, "_token": "<?php echo e(csrf_token()); ?>" },
                success: function (data) {
                    // Actualiza el campo de entrada con el número de teléfono del usuario
                    $('#photo_user').attr('src', data.photo);
                    $('#ci_user').val(data.ci);
                    $('#phone_user').val(data.phone);
                },
                error: function (error) {
                    console.log(error);
                }
            });
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', ['activePage' => 'porterias', 'titlePage' => 'Nueva Porteria'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Arnez\Desktop\casadesenet-main\resources\views/porterias/create.blade.php ENDPATH**/ ?>