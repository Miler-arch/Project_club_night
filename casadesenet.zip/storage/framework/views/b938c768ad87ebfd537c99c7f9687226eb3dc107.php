<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <form action="<?php echo e(route('users.store')); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="card">
            <div class="card-header card-header-primary">
              <h4 class="card-title">Nuevo Usuario</h4>
            </div>
              <div class="card-body">
                <div class="row">
                  <label for="name" class="col-sm-2 col-form-label">Nombre :</label>
                    <div class="col-sm-7">
                        <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" autofocus>
                        <?php if($errors->has('name')): ?>
                        <span class="error text-danger" for="input-name"><?php echo e($errors->first('name')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row">
                    <label for="username" class="col-sm-2 col-form-label">Nombre de Usuario :</label>
                    <div class="col-sm-7">
                        <input type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>">
                        <?php if($errors->has('username')): ?>
                        <span class="error text-danger" for="input-username"><?php echo e($errors->first('username')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row">
                    <label for="ci" class="col-sm-2 col-form-label">Carnet de Identidad :</label>
                    <div class="col-sm-7">
                        <input type="number" class="form-control" name="ci" value="<?php echo e(old('ci')); ?>">
                        <?php if($errors->has('ci')): ?>
                            <span class="error text-danger" for="input-ci"><?php echo e($errors->first('ci')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row">
                    <label for="phone" class="col-sm-2 col-form-label">Teléfono :</label>
                    <div class="col-sm-7">
                        <input type="number" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>">
                             <?php if($errors->has('phone')): ?>
                            <span class="error text-danger" for="input-phone"><?php echo e($errors->first('phone')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row">
                  <label for="email" class="col-sm-2 col-form-label">Correo Electrónico:</label>
                  <div class="col-sm-7">
                    <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">
                    <?php if($errors->has('email')): ?>
                      <span class="error text-danger" for="input-email"><?php echo e($errors->first('email')); ?></span>
                    <?php endif; ?>
                  </div>
                </div>

                <div class="row">
                  <label for="password" class="col-sm-2 col-form-label">Contraseña :</label>
                  <div class="col-sm-7">
                    <input type="password" class="form-control" name="password">
                    <?php if($errors->has('password')): ?>
                      <span class="error text-danger" for="input-password"><?php echo e($errors->first('password')); ?></span>
                    <?php endif; ?>
                  </div>
                </div>
                <div class="row">
                    <label for="roles" class="col-sm-2 col-form-label">Roles :</label>
                    <div class="col-3">
                        <div class="form-group">
                            <div class="tab-content">
                                <div class="tab-pane active">
                                    <table class="table">
                                        <thead>
                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <div class="form-check">
                                                        <label class="form-check-label">
                                                        <input type="checkbox" class="form-check-input" name="roles[]"
                                                        value="<?php echo e($id); ?>">
                                                        <span class="form-check-sign">
                                                            <span class="check"></span>
                                                        </span>
                                                        </label>
                                                    </div>
                                                </td>
                                                <td>
                                                    <?php echo e($role); ?>

                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div>
                        <input type="file" name="photo" id="photo">
                            <div class="col">
                            <img id="imagenSeleccionada" style="max-height: 200px;">
                        </div>
                        <?php if($errors->has('photo')): ?>
                            <span class="error text-danger"><?php echo e($errors->first('photo')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
              </div>
              <div class="card-footer ml-auto mr-auto">
                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-success mr-3">Cancelar</a>
                <button type="submit" class="btn btn-primary">Guardar</button>
              </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
    $(document).ready(function (e){
        $('#photo').change(function(){
        let reader = new FileReader();
        reader.onload = (e) => {
            $('#imagenSeleccionada').attr('src', e.target.result);
        }
        reader.readAsDataURL(this.files[0]);
        });
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', ['activePage' => 'users'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\casadesenet\resources\views/users/create.blade.php ENDPATH**/ ?>