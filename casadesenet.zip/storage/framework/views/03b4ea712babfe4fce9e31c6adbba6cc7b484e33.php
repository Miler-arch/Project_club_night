<?php $__env->startSection('content'); ?>
    <div class="content">
      <div class="content-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-header card-header-primary">
                    <h4 class="card-title">Chicas</h4>
                    <p class="card-category">Chicas registradas</p>
                  </div>
                  <div class="card-body">
                    <div class="row">
                      <div class="col-12 text-right">
                        <a href="<?php echo e(route('chicas.create')); ?>" class="btn btn-sm btn-facebook">Registrar Chica</a>
                      </div>
                    </div>
                    <div class="table-responsive">
                      <table class="table">
                        <thead class="text-primary">
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Edad</th>
                            <th>Fecha de Vencimiento</th>
                            <th>Código</th>
                            <th>Carnet de Identidad</th>
                            <th>Teléfono</th>
                            <th>Estado</th>
                            <th>Imagen</th>
                            <th>Fecha de Creación</th>
                            <th class="text-right">Acciones</th>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $chicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $chica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($chica->name); ?></td>
                                <td><?php echo e($chica->age); ?></td>
                                <td>
                                    <?php if($chica->health_card_expiry_date): ?>
                                        <span class="bg-primary rounded text-white font-weight-bold p-2"><?php echo e($chica->health_card_expiry_date); ?></span>
                                    <?php else: ?>
                                        <span class="bg-danger rounded text-white font-weight-bold p-2">No registrado</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($chica->code_card): ?>
                                        <span class="bg-primary rounded text-white font-weight-bold p-2"><?php echo e($chica->code_card); ?></span>
                                    <?php else: ?>
                                        <span class="bg-danger rounded text-white font-weight-bold p-2">No registrado</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($chica->ci); ?></td>
                                <td><?php echo e($chica->phone); ?></td>
                                <td>
                                    <?php if($chica->state_chica === 1): ?>
                                        <span class="badge-success rounded p-2 pl-5 pr-5 font-weight-bold">Activo</span>
                                    <?php elseif($chica->state_chica === 0): ?>
                                        <span class="badge-danger rounded p-2 pl-5 pr-5 font-weight-bold">Inactivo</span>
                                    <?php elseif($chica->state_chica === 2): ?>
                                        <span class="badge-warning rounded p-2 pl-5 pr-5 font-weight-bold">Bloqueado</span>
                                    <?php endif; ?>
                                </td>
                              <td>
                                <img src="/imagen/<?php echo e($chica->image); ?>" width="50%">
                              </td>
                              <td><?php echo e($chica->created_at); ?></td>
                              <td class="td-actions text-right">
                                <a href="<?php echo e(route('chicas.show', $chica->id)); ?>"><button style="background-color: cornflowerblue;
                                  color:white;
                                  border-radius:20px;
                                  cursor: pointer;
                                  border: 0;"> Ver manillas </button>
                                <a href="<?php echo e(route('chicas.edit', $chica->id)); ?>" class="btn btn-warning"><i class="material-icons">edit</i></a>
                                <form action="<?php echo e(route('chicas.destroy', $chica->id)); ?>" method="post" style="display: inline-block;" class="form-eliminar">
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('DELETE'); ?>
                                  <button class="btn btn-danger" type="submit">
                                    <i class="material-icons">close</i>
                                  </button>
                                </form>
                              </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                        <div class="card-footer justify-content-center">
                          <?php echo e($chicas->links()); ?>

                        </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php if(session('eliminar') == 'ok'): ?>
      <script>
        Swal.fire(
      'Eliminado',
      'El usuario ha sido eliminado.',
      'success'
        )
      </script>
    <?php endif; ?>
<script type="text/javascript">
  $('.form-eliminar').submit(function(e){

    e.preventDefault();

    Swal.fire({
    title: '¿Esta seguro?',
    text: "El usuario se eliminara definitivamente.",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Si, eliminar',
    cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.value) {
        //   Swal.fire(
        //     'Deleted!',
        //     'Your file has been deleted.',
        //     'success'
        // )
        this.submit();
    }
    })
});
</script>

    <?php if(session('success')): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Éxito',
                text: '<?php echo e(session('success')); ?>',
                showConfirmButton: false,
                timer: 1000
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', ['activePage' => 'chicas', 'titlePage' => 'Chicas'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\casadesenet\resources\views/chicas/index.blade.php ENDPATH**/ ?>