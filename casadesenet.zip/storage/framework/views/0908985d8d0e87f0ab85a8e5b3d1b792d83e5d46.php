<?php $__env->startSection('content'); ?>
    <div class="content">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header card-header-primary">
                <div class="card-title">Usuarios</div>
                <p class="card-category">Vista detallada del usuario de <?php echo e($user->name); ?></p>
              </div>

              <div class="card-body">
              <?php if(session('success')): ?>
                      <div class="alert alert-success" role="success">
                        <?php echo e(session('success')); ?>

                      </div>
              <?php endif; ?>
                <div class="row justify-content-center">
                  <div class="col-md-4">
                      <div class="card">
                          <div class="card-header bg-primary text-white">
                              <h4 class="card-title font-weight-bold"><?php echo e($user->name); ?></h4>
                          </div>
                          <div class="card-body">
                              <div class="text-center mb-3">
                                  <img src="/imagen/<?php echo e($user->photo); ?>" alt="<?php echo e($user->name); ?>" width="300" height="300">
                              </div>
                              <p class="card-text">
                                    <b>Usuario:</b> <?php echo e($user->username); ?><br>
                                    <b>Email:</b> <?php echo e($user->email); ?><br>
                                    <b>Carnet de identidad:</b><?php echo e($user->ci); ?><br>
                                    <b>Teléfono:</b><?php echo e($user->phone); ?><br>
                                    <b>Fecha de Creación:</b> <?php echo e($user->created_at); ?>

                              </p>
                              <p class="card-text">
                                  <strong>Roles:</strong>
                                  <?php $__empty_1 = true; $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                      <span class="badge badge-dark"><?php echo e($role->name); ?></span>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                      <span class="badge badge-danger">No tiene roles</span>
                                  <?php endif; ?>
                              </p>
                          </div>
                          <div class="card-footer">
                              <div class="d-flex justify-content-center">
                                  <a href="<?php echo e(route('users.index')); ?>" class="btn btn-success mr-3">Volver</a>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', ['activePage' => 'users', 'titlePage' => 'Detalles del usuario'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\casadesenet\resources\views/users/show.blade.php ENDPATH**/ ?>