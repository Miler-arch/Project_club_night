<?php $__env->startSection('content'); ?>
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header card-header-primary">
                <div class="card-title">Permisos</div>
                <p class="card-category">Vista detallada del permiso de <?php echo e($permission->name); ?></p>
              </div>

              <div class="card-body">
              <?php if(session('success')): ?>
                      <div class="alert alert-success" role="success">
                        <?php echo e(session('success')); ?>

                      </div>
              <?php endif; ?>
                <div class="row">
                  <div class="col-md-3">
                    <div class="card card-user">
                      <div class="card-body">
                        <p class="card-text">
                          <div class="author">
                            <a href="#" class="d-flex">
                              <img src="<?php echo e(asset('/img/avatar.png')); ?>" alt="avatar" class="avatar">
                              <h5 class="title mx-3"><?php echo e($permission->name); ?></h5>
                            </a>
                            <p class="description">
                              <?php echo e($permission->guard_name); ?> <br>
                              <?php echo e($permission->created_at); ?>

                            </p>
                          </div>
                        </p>
                        <div class="card-description">
                          
                        </div> 
                      </div>
                      <div class="card-footer">
                        <div class="button-container">
                          <a href="<?php echo e(route('permissions.index')); ?>" class="btn btn-sm btn-success mr-3"> Volver </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['activePage' => 'permissions', 'titlePage' => 'Detalles del permiso'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Arnez\Desktop\casadesenet-main\resources\views/permissions/show.blade.php ENDPATH**/ ?>