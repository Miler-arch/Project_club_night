<footer class="footer">
    <div class="container">
        
        <div class="copyright">
        &copy;
        <script>
            document.write(new Date().getFullYear())
        </script> La Casa de Senet
    </div>
</footer><?php /**PATH C:\Users\Arnez\Desktop\casadesenet-main\resources\views/layouts/footers/guest.blade.php ENDPATH**/ ?>