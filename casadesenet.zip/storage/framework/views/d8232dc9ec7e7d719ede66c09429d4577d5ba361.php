<div class="sidebar" data-color="orange">

  <div class="logo">
    <a class="simple-text logo-normal text-1">
    <?php echo e(__('La Casa de Senet')); ?>

    </a>
  </div>
  <div class="sidebar-wrapper">
    <ul class="nav">

      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.index')): ?>
      <li class="nav-item<?php echo e($activePage == 'users' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
          <i class='bx bx-user-plus' style='color:#0ba1f7'  ></i>
            <p><?php echo e(__('Usuarios')); ?></p>
        </a>
      </li>
      <?php endif; ?>

      
        <li class="nav-item<?php echo e($activePage == 'clients' ? ' active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('clients.index')); ?>">
            <i class='bx bxs-user-rectangle' style='color:#0981d1'></i>
                <p><?php echo e(__('Clientes')); ?></p>
            </a>
        </li>
      

        <li class="nav-item<?php echo e($activePage == 'porterias' ? ' active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('porterias.index')); ?>">
            <i class='bx bx-desktop' style='color:#09d14f'></i>
                <p><?php echo e(__('Porteria')); ?></p>
            </a>
        </li>

      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permissions.index')): ?>
      <li class="nav-item<?php echo e($activePage == 'permissions' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('permissions.index')); ?>">
          <i class='bx bxs-lock' style='color:#ea8c0e'  ></i>
          <p><?php echo e(__('Permisos')); ?></p>
        </a>
      </li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.index')): ?>
      <li class="nav-item<?php echo e($activePage == 'roles' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('roles.index')); ?>">
          <i class='bx bxs-user-badge' style='color:#0be4ec'  ></i>
            <p><?php echo e(__('Roles')); ?></p>
        </a>
      </li>
      <?php endif; ?>

      <li class="nav-item<?php echo e($activePage == 'productos' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('productos.index')); ?>">
          <i class='bx bx-cart' style='color:#e8f510'  ></i>
          <p><?php echo e(__('Productos')); ?></p>
        </a>
      </li>

      <li class="nav-item<?php echo e($activePage == 'ventas' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('ventas.index')); ?>">
          <i class='bx bxs-store-alt' style='color:#ee5909'  ></i>
          <p><?php echo e(__('Ventas')); ?></p>
        </a>
      </li>

      <li class="nav-item<?php echo e($activePage == 'chicas' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('chicas.index')); ?>">
          <i class='bx bx-female' style='color:#ef0c99'  ></i>
          <p><?php echo e(__('Chicas')); ?></p>
        </a>
      </li>

      <li class="nav-item<?php echo e($activePage == 'manillas' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('manillas.index')); ?>">
          <i class='bx bx-circle' style='color:#b506f1'  ></i>
          <p><?php echo e(__('Manillas')); ?></p>
        </a>
      </li>

      <li class="nav-item<?php echo e($activePage == 'piezas' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('piezas.index')); ?>">
          <i class='bx bx-door-open' style='color:#0decea'  ></i>
          <p><?php echo e(__('Piezas')); ?></p>
        </a>
      </li>

      <li class="nav-item<?php echo e($activePage == 'reportes' ? ' active' : ''); ?>">
        <a class="nav-link" href="">
          <i class='bx bxs-report' style='color:#7aec07'  ></i>
          <p><?php echo e(__('Reportes')); ?></p>
        </a>
      </li>

      <li class="nav-item<?php echo e($activePage == 'gastos' ? ' active' : ''); ?>">
        <a class="nav-link" href="">
          <i class='bx bx-money-withdraw' style='color:#0897f7'  ></i>
          <p><?php echo e(__('Gastos')); ?></p>
        </a>
      </li>


    </ul>
  </div>
</div>
<?php /**PATH C:\laragon\www\casadesenet\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>