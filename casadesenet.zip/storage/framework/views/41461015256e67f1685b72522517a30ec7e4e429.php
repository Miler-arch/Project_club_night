<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <form action="<?php echo e(route('piezas.store')); ?>" method="post" class="form-horizontal">
          
          <?php echo csrf_field(); ?>
          <div class="card">
            <div class="card-header card-header-primary">
              <h4 class="card-title">Pieza</h4>
              <p class="card-category">Ingresar datos</p>
            </div>
              <div class="card-body">
                
                
                <div class="row">
                  <label for="nombre_chica" class="col-sm-2 col-form-label">Nombre Completo :</label>
                  <div class="col-sm-7">
                    <input type="text" class="form-control" name="nombre_chica" placeholder="Nombre completo" value="<?php echo e(old('nombre_chica')); ?>" autofocus>
                    <?php if($errors->has('nombre_chica')): ?>
                      <span class="error text-danger" for="input-nombre_chica"><?php echo e($errors->first('nombre_chica')); ?></span>
                    <?php endif; ?>
                  </div>
                </div>
                
                
                <div class="row">
                  <label for="tiempo" class="col-sm-2 col-form-label">Tiempo :</label>
                  <div class="col-sm-7">
                    <input type="number" class="form-control" name="tiempo" placeholder="minutos/horas" value="<?php echo e(old('tiempo')); ?>">
                    <?php if($errors->has('tiempo')): ?>
                      <span class="error text-danger" for="input-tiempo"><?php echo e($errors->first('tiempo')); ?></span>
                    <?php endif; ?>
                  </div>
                </div>
                
                <div class="row">
                  <label for="hora_ingreso" class="col-sm-2 col-form-label">Hora de Ingreso :</label>
                  <div class="col-sm-7">
                    <input type="time" class="form-control" name="hora_ingreso">
                    <?php if($errors->has('hora_ingreso')): ?>
                      <span class="error text-danger" for="input-hora_ingreso"><?php echo e($errors->first('hora_ingreso')); ?></span>
                    <?php endif; ?>
                  </div>
                </div>
                
                <div class="row">
                  <label for="hora_salida" class="col-sm-2 col-form-label">Hora de Salida :</label>
                  <div class="col-sm-7">
                    <input type="time" class="form-control" name="hora_salida">
                    <?php if($errors->has('hora_salida')): ?>
                      <span class="error text-danger" for="input-hora_salida"><?php echo e($errors->first('hora_salida')); ?></span>
                    <?php endif; ?>
                  </div>
                </div>

                <div class="row">
                  <label for="ingreso" class="col-sm-2 col-form-label">Ingreso :</label>
                  <div class="col-sm-7">
                    <input type="number" class="form-control" name="ingreso">
                    <?php if($errors->has('ingreso')): ?>
                      <span class="error text-danger" for="input-ingreso"><?php echo e($errors->first('ingreso')); ?></span>
                    <?php endif; ?>
                  </div>
                </div>

                
                
                
              </div>
              <div class="card-footer ml-auto mr-auto">
                <a href="<?php echo e(route('piezas.index')); ?>" class="btn btn-success mr-3">Cancelar</a>
                <button type="submit" class="btn btn-primary">Guardar</button>
              </div>
            
          </div>

        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['activePage' => 'piezas', 'titlePage' => 'Nueva Pieza'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Arnez\Desktop\casadesenet-main\resources\views/piezas/create.blade.php ENDPATH**/ ?>