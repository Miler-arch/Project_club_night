<?php $__env->startSection('content'); ?>
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header card-header-primary">
                <div class="card-title">SALIR</div>
              </div>







                <a href="<?php echo e(route('porterias.index')); ?>" class="btn btn-sm btn-success mr-3"> Volver </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', ['activePage' => 'porterias', 'titlePage' => 'Salir '], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\casadesenet\resources\views/porterias/show.blade.php ENDPATH**/ ?>