
    
    <?php /**PATH C:\Users\Arnez\Desktop\casadesenet-main\resources\views/layouts/footers/auth.blade.php ENDPATH**/ ?>