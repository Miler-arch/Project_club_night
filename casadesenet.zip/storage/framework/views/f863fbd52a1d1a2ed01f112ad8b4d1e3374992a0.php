<?php $__env->startSection('content'); ?>
    <div class="content">
      <div class="content-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-header card-header-primary">
                    <h4 class="card-title">Clientes</h4>
                  </div>
                  <div class="card-body">
                    <div class="row">
                      <div class="col-12 text-right">
                        
                            <a href="<?php echo e(route('clients.create')); ?>" class="btn btn-sm btn-facebook">Añadir Cliente</a>
                        
                      </div>
                    </div>
                    <div class="table-responsive">
                      <table class="table">
                        <thead class="text-primary">
                            <th>ID</th>
                            <th>Cajero</th>
                            <th>Nombre</th>
                            <th>Teléfono</th>
                            <th>Prenda</th>
                            <th>Monto</th>
                            <th>Entregar Prenda</th>
                            <th class="text-right">Acciones</th>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($client->id); ?></td>
                            <td><?php echo e($client->user->name); ?></td>
                            <td><?php echo e($client->name); ?></td>
                            <td><?php echo e($client->phone); ?></td>
                            <td>
                                <?php if($client->description): ?>
                                    <span class="bg-primary text-white rounded p-2 font-weight-bold"><?php echo e($client->description); ?></span>
                                <?php else: ?>
                                    <span class="bg-danger text-white rounded p-2 font-weight-bold">No dejo prenda</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($client->amount): ?>
                                    <b class="font-weight-bold"><?php echo e($client->amount); ?> Bs.</b>
                                <?php else: ?>
                                    <span class="bg-danger text-white rounded p-2 font-weight-bold">No hay monto</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($client->description && $client->amount): ?>
                                    <form action="<?php echo e(route('clients.update', $client->id)); ?>" method="post" class="form-horizontal form-entregado">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <input type="hidden" name="description" value="">
                                        <input type="hidden" name="amount" value="">
                                        <button type="submit" class="btn btn-sm btn-success">Entregar Prenda</button>
                                    </form>
                                <?php else: ?>
                                    <span class="bg-danger text-white rounded p-2 font-weight-bold bg-danger-subtle">No hay prendas por entregar</span>
                                <?php endif; ?>
                            </td>

                            <td class="td-actions text-right">
                              
                              <a href="<?php echo e(route('clients.show', $client->id)); ?>" class="btn btn-info"><i class="material-icons">person</i></a>
                              
                              
                              <a href="<?php echo e(route('clients.edit', $client->id)); ?>" class="btn btn-warning"><i class="material-icons">edit</i></a>
                              
                              
                              <form action="<?php echo e(route('clients.destroy', $client->id)); ?>" method="post" style="display: inline-block;" class="form-eliminar">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger" type="submit">
                                  <i class="material-icons">close</i>
                                </button>
                              </form>
                              
                            </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                    <div class="card-footer justify-content-center">
                      <?php echo e($clients->links()); ?>

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php if(session('eliminar') == 'ok'): ?>
      <script>
        Swal.fire(
      'Eliminado',
      'El cliente ha sido eliminado.',
      'success'
        )
      </script>
    <?php endif; ?>
    <script type="text/javascript">
    $('.form-eliminar').submit(function(e){

    e.preventDefault();

    Swal.fire({
    title: '¿Esta seguro?',
    text: "El cliente se eliminara definitivamente.",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Si, eliminar',
    cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.value) {
        //   Swal.fire(
        //     'Deleted!',
        //     'Your file has been deleted.',
        //     'success'
        // )
        this.submit();
    }
    })
    });
    </script>

    <script type="text/javascript">
    $('.form-entregado').submit(function(e){

    e.preventDefault();

    Swal.fire({
        title: '¿Esta seguro?',
        text: "¿Cobrar y entregar la prenda?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Si, Entregar',
        cancelButtonText: 'Cancelar'
        }).then((result) => {
        if (result.value) {
            this.submit();
        }
        });
    });
    </script>

    <?php if(session('success')): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Éxito',
                text: '<?php echo e(session('success')); ?>',
                showConfirmButton: false,
                timer: 1000
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', ['activePage' => 'clients', 'titlePage' => 'Clientes'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Arnez\Desktop\casadesenet-main\resources\views/clients/index.blade.php ENDPATH**/ ?>