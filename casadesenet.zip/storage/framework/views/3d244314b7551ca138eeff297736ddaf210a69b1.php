<?php $__env->startSection('content'); ?>
    <div class="content">
      <div class="content-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-header card-header-primary">
                    <h4 class="card-title">Ventas</h4>
                    <p class="card-category">Ventas registradas</p>
                  </div>
                  <div class="card-body">
                    <?php if(session('success')): ?>
                      <div class="alert alert-success" role="success">
                        <?php echo e(session('success')); ?>

                      </div>
                    <?php endif; ?>

                    
                     <div class="row">
                      <div class="col-12 text-right">
                        
                         <a href="<?php echo e(route('ventas.create')); ?>" class="btn btn-sm btn-facebook">Nueva Venta</a>
                        
                        
                        
                       </div>
                    </div>
                    <div class="table-responsive">
                      <table class="table">
                        <thead class="text-primary">
                          <th>Numero de Venta</th>
                          <th>Garzón</th>
                          <th>Total</th>
                          <th>Fecha/Hora</th>
                          <th>Estado</th>
                          
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($venta->id); ?></td>
                            <td><?php echo e($venta->user->name); ?></td>
                            <td><?php echo e($venta->total); ?> Bs.</td>
                            <td><?php echo e($venta->created_at); ?></td>
                            
                            <?php if($venta->estado == 'PENDIENTE'): ?>
                                <td>
                                    <a class="btn btn-warning" href="<?php echo e(route('cambio.estado.ventas', $venta)); ?>"
                                        title="Pendiente">
                                        Pendiente <i class='bx bx-x' style='color:#edf1f1' ></i>
                                    </a>
                                </td>
                            <?php else: ?>
                                <td>
                                    <a class="btn btn-success" href="<?php echo e(route('cambio.estado.ventas', $venta)); ?>"
                                        title="Cancelar">
                                        Cancelado <i class='bx bx-check' style='color:#f5f7f7'  ></i>
                                    </a>
                                </td>
                            <?php endif; ?>
                      
                            
                            <td class="td-actions text-right">
                              
                              
                              
                              
                              
                              
                              
                              
                              
                            </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                    <div class="card-footer justify-content-center">
                      <?php echo e($ventas->links()); ?>

                    </div>
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php if(session('success')): ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert">
          <strong> Guardado!</strong> <?php echo e(session('success')); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close" >
              <span aria-hidden="true">&times;</span>
          </button>
      </div>
      <?php elseif(session('error')): ?>
          <div class="alert alert-danger alert-dismissible fade show" role="alert" >
              <strong> Error !</strong> <?php echo e(session('error')); ?>

              <button type="button" class="close" data-dismiss="alert" aria-label="Close" >
                  <span aria-hidden="true">&times;</span>
              </button>
          </div>
      <?php endif; ?>
      <?php if(session('cancelado')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert" style="text-align: center; width:400px; margin-left:38%; border-radius:30px;">
              <?php echo e(session('cancelado')); ?>

              <button type="button" class="close" data-dismiss="alert" aria-label="Close" >
                  <span aria-hidden="true">&times;</span>
              </button>
          </div>
      <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php if(session('eliminar') == 'ok'): ?>
      <script>
        Swal.fire(
      'Eliminado',
      'La venta ha sido eliminada.',
      'success'
        )
      </script>
    <?php endif; ?>
<script type="text/javascript">
  $('.form-eliminar').submit(function(e){

  e.preventDefault();
  
  Swal.fire({
  title: '¿Esta seguro?',
  text: "La venta se eliminara definitivamente.",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Si, eliminar',
  cancelButtonText: 'Cancelar'
  }).then((result) => {
    if (result.value) {
    //   Swal.fire(
    //     'Deleted!',
    //     'Your file has been deleted.',
    //     'success'
    // )
    this.submit();
  }
})
});
</script>

<script>
  window.setTimeout(() => {
    $(".alert").fadeTo(1500, 0).slideDown(1000, 
    function(){
      $(this).remove();
    });
  }, 700);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['activePage' => 'ventas', 'titlePage' => 'Ventas'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\casadesenet\resources\views/ventas/index.blade.php ENDPATH**/ ?>