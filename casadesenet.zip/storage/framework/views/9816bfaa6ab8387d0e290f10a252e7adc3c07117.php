<?php $__env->startSection('content'); ?>
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header card-header-primary">
                <div class="card-title"><?php echo e($chica->nombre_chica); ?></div>
                  <p class="card-category">Manillas</p>
                    </div>
                      <div class="card-body">
                        <?php if(session('success')): ?>
                              <div class="alert alert-success" role="success">
                                <?php echo e(session('success')); ?>

                              </div>
                        <?php endif; ?>
                        <?php $__currentLoopData = $chica->manilla; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manilla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          
                          <div class="card" style="width: 18rem;">      
                           <div class="card-body">         
                                    Color: <?php echo e($manilla->color); ?> <br>
                                    Precio: <?php echo e($manilla->precio); ?> Bs. <br>
                                    Cantidad: <?php echo e($manilla->pivot->cantidad); ?> <br>
                                    Monto Total: <?php echo e($manilla->pivot->monto); ?> Bs. <br>
                                    <?php if($manilla->pivot->cantidad > 0 ): ?>
                                        <td>
                                            <a class="btn btn-warning" href="<?php echo e(route('cambio.estado.chicas', [$chica, $manilla])); ?>"
                                                title="Pendiente">
                                                Pendiente <i class='bx bx-x' style='color:#edf1f1' ></i>
                                            </a>
                                            
                                        </td>
                                    <?php else: ?>
                                        <td>
                                            <a class="btn btn-success" href="<?php echo e(route('cambio.estado.chicas', [$chica, $manilla])); ?>"
                                                title="Cancelar">
                                                Cancelado <i class='bx bx-check' style='color:#f5f7f7'  ></i> 
                                            </a>
                                        </td>
                                    <?php endif; ?> 
                                </div>
                                <div class="card-footer">
                                  <div class="button-container">
                                  <a href="<?php echo e(route('chicas.index')); ?>" class="btn btn-sm btn-success mr-3"> Volver </a>
                                  </div>
                                </div>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(session('success')): ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert" >
          <strong> Guardado!</strong> <?php echo e(session('success')); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close" >
              <span aria-hidden="true">&times;</span>
          </button>
      </div>
      <?php elseif(session('error')): ?>
          <div class="alert alert-danger alert-dismissible fade show" role="alert" >
              <strong> Error !</strong> <?php echo e(session('error')); ?>

              <button type="button" class="close" data-dismiss="alert" aria-label="Close" >
                  <span aria-hidden="true">&times;</span>
              </button>
          </div>
      <?php endif; ?>
      <?php if(session('cancelado')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert" style="text-align: center; width:400px; margin-left:38%; border-radius:30px;">
              <?php echo e(session('cancelado')); ?>

              <button type="button" class="close" data-dismiss="alert" aria-label="Close" >
                  <span aria-hidden="true">&times;</span>
              </button>
          </div>
      <?php endif; ?>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<script>
  window.setTimeout(() => {
    $(".alert").fadeTo(1500, 0).slideDown(1000, 
    function(){
      $(this).remove();
    });
  }, 700);
</script>



<?php echo $__env->make('layouts.main', ['activePage' => 'chicas', 'titlePage' => 'Detalles de chica'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Arnez\Desktop\casadesenet-main\resources\views/chicas/show.blade.php ENDPATH**/ ?>