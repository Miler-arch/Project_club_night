<?php $__env->startSection('content'); ?>
    <div class="content">
      <div class="content-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-header card-header-primary">
                    <h4 class="card-title">Piezas</h4>
                    <p class="card-category">Piezas registradas</p>
                  </div>
                  <div class="card-body">
                    <?php if(session('success')): ?>
                      <div class="alert alert-success" role="success">
                        <?php echo e(session('success')); ?>

                      </div>
                    <?php endif; ?>
                    <div class="row">
                      <div class="col-12 text-right">
                        
                        <a href="<?php echo e(route('piezas.create')); ?>" class="btn btn-sm btn-facebook">Registrar Pieza</a>
                        
                      </div>
                    </div>
                    <div class="table-responsive">
                      <table class="table">
                        <thead class="text-primary">
                          
                          <th>ID</th>
                          <th>Nombre</th>
                          <th>Tiempo</th>
                          <th>Horario/Ingreso</th>
                          <th>Horario/Salida</th>
                          <th>Ingreso Total</th>
                          <th>Fecha de Creación</th>
                          <th class="text-right">Acciones</th>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $piezas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pieza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($pieza->id); ?></td>
                            <td><?php echo e($pieza->nombre_chica); ?></td>
                            <td><?php echo e($pieza->tiempo); ?></td>
                            <td><?php echo e($pieza->hora_ingreso); ?></td>
                            <td><?php echo e($pieza->hora_salida); ?></td>
                            <td><?php echo e($pieza->ingreso); ?></td>
                            <td><?php echo e($pieza->created_at); ?></td>

                            
                            
                            <td class="td-actions text-right">
                              
                              <a href="<?php echo e(route('piezas.show', $pieza->id)); ?>" class="btn btn-info"><i class="material-icons">person</i></a>
                              
                              
                              <a href="<?php echo e(route('piezas.edit', $pieza->id)); ?>" class="btn btn-warning"><i class="material-icons">edit</i></a>
                              
                              
                              <form action="<?php echo e(route('piezas.destroy', $pieza->id)); ?>" method="post" style="display: inline-block;" class="form-eliminar"> 
                              <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger" type="submit">
                                  <i class="material-icons">close</i>
                                </button>
                              </form>   
                              
                            
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                    <div class="card-footer justify-content-center">
                      <?php echo e($piezas->links()); ?>

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php if(session('eliminar') == 'ok'): ?>
      <script>
        Swal.fire(
      'Eliminado',
      'La pieza ha sido eliminada.',
      'success'
        )
      </script>
    <?php endif; ?>
<script type="text/javascript">
  $('.form-eliminar').submit(function(e){

  e.preventDefault();
  
  Swal.fire({
  title: '¿Esta seguro?',
  text: "La pieza se eliminara definitivamente.",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Si, eliminar',
  cancelButtonText: 'Cancelar'
  }).then((result) => {
    if (result.value) {
    //   Swal.fire(
    //     'Deleted!',
    //     'Your file has been deleted.',
    //     'success'
    // )
    this.submit();
  }
})
});
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.main', ['activePage' => 'piezas', 'titlePage' => 'Piezas'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\casadesenet\resources\views/piezas/index.blade.php ENDPATH**/ ?>